package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Adapter
import android.widget.ListView
import android.widget.TextView
import androidx.constraintlayout.helper.widget.MotionEffect
import androidx.constraintlayout.helper.widget.MotionEffect.TAG
import com.google.firebase.auth.FirebaseAuth

class Recette : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recette)

        val deconnexion=findViewById<TextView>(R.id.deconnexion)

        deconnexion.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val deco = Intent(this, MainActivity::class.java)
            startActivity(deco)

        }

        db.collection("recettes")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    Log.d(TAG, "${document.id} => ${document.data}")
                }
            }
            .addOnFailureListener { exception ->
                Log.w(TAG, "Error getting documents.", exception)
            }

        val ajoutrecettes=findViewById<TextView>(R.id.ajout_recettes)

        ajoutrecettes.setOnClickListener {
            val recettes = hashMapOf(
                "nom recette" to "miam ",
                "recette" to "gateau"
            )

            db.collection("recettes")
                .add(recettes)
                .addOnSuccessListener { documentReference ->
                    Log.d(
                        MotionEffect.TAG,
                        "DocumentSnapshot added with ID: ${documentReference.id}"
                    )
                }
                .addOnFailureListener { e ->
                    Log.w(MotionEffect.TAG, "Error adding document", e)
                }
        }
    }
}

