package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth


class Inscription : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inscription)

        val goback=findViewById<TextView>(R.id.goback)

        goback.setOnClickListener {
            val goback = Intent(this, MainActivity::class.java)
            startActivity(goback)
        }

        val boutonvalider=findViewById<TextView>(R.id.boutonvalider)

        boutonvalider.setOnClickListener {
            val mdp = findViewById<EditText>(R.id.case_mdp)
            val verifmdp = findViewById<EditText>(R.id.case_verifmdp)
            val str_mdp = mdp.text.toString()
            val str_verifmdp = verifmdp.text.toString()
            if(str_mdp != str_verifmdp) {
                Toast.makeText(
                    this,
                    "Les mots de passe ne sont pas identiques, réessayez",
                    Toast.LENGTH_LONG
                ).show()
            }

            val email = findViewById<EditText>(R.id.case_email)
            val str_email = email.text.toString()
            val testemail ="@"

            if(str_email.contains(testemail) ) {
            }
            else {
                Toast.makeText(
                    this,
                    "Rentrez une adresse email valide",
                    Toast.LENGTH_LONG
                ).show()
            }

            registerUser(str_email, str_mdp)

            val boutonvaliderr = Intent(this, Recette::class.java)
            startActivity(boutonvaliderr)
        }

    }

}

