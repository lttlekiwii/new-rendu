package com.example.myapplication

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.helper.widget.MotionEffect.TAG
import com.example.myapplication.Connexion
import com.example.myapplication.R
import com.google.firebase.FirebaseApp

class MainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        FirebaseApp.initializeApp(this)

        val ConnexionButton=findViewById<Button>(R.id.button)

        ConnexionButton.setOnClickListener {
            val conn = Intent(this, Connexion::class.java)
            startActivity(conn)
            }

        val InscriptionButton=findViewById<Button>(R.id.button3)

        InscriptionButton.setOnClickListener {
            val ins = Intent(this, Inscription::class.java)
            startActivity(ins)
        }

        val invit=findViewById<TextView>(R.id.invite)

        invit.setOnClickListener {
            val inv = Intent(this, Recette::class.java)
            startActivity(inv)
        }
        }

}