package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class Connexion : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_connexion)

        val goback=findViewById<TextView>(R.id.goback)

        goback.setOnClickListener {
            val goback = Intent(this, MainActivity::class.java)
            startActivity(goback)
        }

        val email = findViewById<EditText>(R.id.case_email)
        val str_email = email.text.toString()
        val mdp = findViewById<EditText>(R.id.case_mdp)
        val str_mdp = mdp.text.toString()

        val boutonvalider=findViewById<TextView>(R.id.boutonvalider)

        boutonvalider.setOnClickListener{
            loginUser(str_email, str_mdp)
            val boutonvaliderr = Intent(this, Recette::class.java)
            startActivity(boutonvaliderr)
        }
    }

}